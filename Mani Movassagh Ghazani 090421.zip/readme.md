A simple shop project Rabbat Land
For admin page i did not made any direct link for sequrity reasons. later i will expand the project with OATH2 ,and with that only admin page will be available.
Database connected to firebase .the main page fetch data from firebase and bring it to the screen.
in admin part , admin can see the warehouse situation and also admin has a possibilities to add direct from admin page new things to database
The project name is only for a learning purpose and not commercial.
all the images is only some relevant randome image links from google search for learning purpose and it is not commercial.
I did not copy the node modules folder and app needs $npm install to work with dependencies properly.
the contact us form, i did reserve it for later to make a node server and add normal submit function attached to server . for learning purpose.
project will be update on my github repo https://github.com/manimovassagh/ShopProjectFinal
Mani Movassagh Ghazani
